#!/bin/bash
# bash script for testing in libsvm in ubuntu setup
cat poutput2 noutput3 > testmine.txt
./svm-train train.txt #training
./svm-predict testmine.txt train.txt.model result.txt  #testing
