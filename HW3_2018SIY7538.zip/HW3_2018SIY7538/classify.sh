#!/bin/bash
# bash script for classifcation of graph given list of graphs, graph labels of active and inactive graphs
#input file--1. graph with ID, vertices and edges in DIMAC format
#intermediate output file 1. discriminative frequent sub graphs 2. feature vector representation of graphs
#intermediate output file---1. training and test dataset using py tool of LIBSVM

#final output---1. creation of training model
#		2. use of training for classification of test data set
#		3. calculation of accuracy and F1 score

# input graph file preprocessing in DIMAC format

# to run classify.sh : classify.sh aido99_all.txt ca.txt ci.txt


python ./process.py "$1" # to preprocess input file e.g 'aido99_all.txt' output- data.txt
sed -i 's/^/1 \t/g' "$2"  # to process (active) file e.g 'ca.txt': inserts cht
sed -i 's/^/0 \t/g' "$3"  # to process (inactive) file e.g 'ci.txt' : inserts cht
cat "$2" "$3" > equal.lab
./gSpan -f equal -l equal.lab -m 21341 -w 1 < data.txt > fsubgraph.txt
python ./findfv.py #to find feature vector pvector.txt & nvector.txt
python ./subset.py -s 1 pvector.txt 125 poutput1 poutput2
python ./subset.py -s 1 nvector.txt 125 noutput1 noutput2
python ./subset.py -s 1 noutput2 125 noutput3 noutput4
cat poutput1 noutput1 > train.txt
python ./postprocess.py # it gives test.txt



#for random selection of feature vector subset.py library of LIBSVM used
#Usage: {0} [options] dataset subset_size [output1] [output2]

#This script randomly selects a subset of the dataset.

#options: -s 1 	: for random selection of feature vectors

#output1 : subset-1
#output2 : subset-2





